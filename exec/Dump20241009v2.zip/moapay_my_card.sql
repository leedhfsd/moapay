-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: moapay
-- ------------------------------------------------------
-- Server version	8.4.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `my_card`
--

DROP TABLE IF EXISTS `my_card`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `my_card` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `amount` bigint DEFAULT NULL,
  `benefit_usage` bigint DEFAULT NULL,
  `card_limit` bigint DEFAULT NULL,
  `card_number` varchar(30) DEFAULT NULL,
  `card_status` bit(1) DEFAULT NULL,
  `cvc` char(3) DEFAULT NULL,
  `member_id` binary(16) DEFAULT NULL,
  `performance_flag` tinyint(1) DEFAULT NULL,
  `uuid` binary(16) NOT NULL,
  `product_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UKimuambgb9ivm9l3xj47b99013` (`card_number`),
  KEY `FK3bcwaonrv398vo8g6ic86720b` (`product_id`),
  CONSTRAINT `FK3bcwaonrv398vo8g6ic86720b` FOREIGN KEY (`product_id`) REFERENCES `card_product` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `my_card`
--

LOCK TABLES `my_card` WRITE;
/*!40000 ALTER TABLE `my_card` DISABLE KEYS */;
INSERT INTO `my_card` VALUES (1,540000,3000,10000000,'3998541707334420',_binary '','123',_binary '�P鴕t���(��\Z',1,_binary '�Q��pm��\�ǟ�Q',1),(2,12000,50,10000000,'6509702494417705',_binary '','456',_binary '�P鴕t���(��\Z',1,_binary '�Q\'n�w���z\�\�Ђ',43),(3,25000,60,10000000,'2114120546082246',_binary '','789',_binary '�P鴕t���(��\Z',1,_binary '�Q\'n�r�	#P�	n',45),(4,350000,1500,10000000,'1796090396860082',_binary '','234',_binary '�P鴕t���(��\Z',0,_binary '�Q\'n�t��ZNAG7�',56),(5,0,0,10000000,'4666117067876136',_binary '','456',_binary '�P鴕t���(��\Z',1,_binary '�Q\'n�sߴ�b�\�R�',68),(6,0,0,10000000,'9278568627446081',_binary '','678',_binary '�P鴕t���(��\Z',1,_binary '�Q\'n�r1���A;o�2',9);
/*!40000 ALTER TABLE `my_card` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-09 17:53:21
