-- MySQL dump 10.13  Distrib 8.0.39, for Linux (x86_64)
--
-- Host: localhost    Database: member
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `member`
--

DROP TABLE IF EXISTS `member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `address` varchar(255) NOT NULL,
  `authenticator_data` tinyblob,
  `birth_date` date NOT NULL,
  `create_time` datetime(6) NOT NULL,
  `credential_id` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `name` varchar(10) NOT NULL,
  `password` varchar(255) NOT NULL,
  `payment_type` enum('BENEFIT','PERFORM') DEFAULT NULL,
  `phone_number` varchar(255) NOT NULL,
  `public_key` varchar(255) DEFAULT NULL,
  `simple_password` varchar(255) DEFAULT NULL,
  `update_time` datetime(6) NOT NULL,
  `uuid` binary(16) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UKerrlnismyy5xmphdt6e4l0oi1` (`uuid`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member`
--

LOCK TABLES `member` WRITE;
/*!40000 ALTER TABLE `member` DISABLE KEYS */;
INSERT INTO `member` VALUES (1,'',NULL,'2000-05-11','2024-10-03 16:20:11.107038',NULL,'dpqls0356@gmail.com','F','이예빈','$2a$10$Gvyb94V3are9qCHRcM8Ds.mSvrW6OMjtsl0AEW3Sv8R1HWkeTVM4q','BENEFIT','01030170356',NULL,'$2a$10$jVTzJuVldIW5VWz.T5caQugVsGKoaNCw6fJskSRFnc/oy25k8COX.','2024-10-03 16:20:26.489156',_binary '�P鴕t��\�(��\Z'),(2,'안알랴줌',NULL,'2001-01-01','2024-10-09 16:43:34.863326',NULL,'qqq@naver.com','F','이예지','$2a$10$EoRsVhMVvkX6cpHu31t/vOFjEYC6588TW2AUypL0ARPDrFs1hrH22','BENEFIT','01076301050',NULL,'$2a$10$fOfajKcl7qWL5ryfZbVH8u.QlrwnjUPW/e5YlsIEmZFo2VGe72qlG','2024-10-09 16:43:55.511329',_binary '0>X�辶	\�\�\�}\�'),(3,'주소입니다',NULL,'2000-01-01','2024-10-09 19:28:49.875306',NULL,'choeh3749@gmail.com','M','최현석','$2a$10$w93va9EGWzbvvtdZWeDy6.BUYPkiStzxaMdibPmdYWDN1pYfBt5iC','BENEFIT','01021107179',NULL,'$2a$10$0pW5Dw8uFp7hc71Kg5kK0exgneyQgewEmGGRM4oX8ozrL4GZLl9OO','2024-10-09 19:29:09.060124',_binary 'F\���)\��\\	�'),(4,'경기도 고양시 일산서구',NULL,'1999-01-04','2024-10-10 14:54:02.238372',NULL,'joo1798@naver.com','F','주수아','$2a$10$dsGxU4fK4Xs9WZV83VbHNOBk5jC.SGQmhR8FLYlicqT1Jo1SL6bOO','BENEFIT','01041181798',NULL,'$2a$10$G9EM/QwFXeF2SiW7jgPsVe1M6oiUn8YYFQP/MZ.3Xk28ZTzfOVXmG','2024-10-10 14:54:35.383915',_binary '\rq�\�\�3ee-�S'),(5,'광주광역시 광산구 수완로 9길',NULL,'2001-03-14','2024-10-10 21:15:47.445679',NULL,'test01@moapay.com','M','김수미','$2a$10$0VPaKnv1GYKJU4sAYTs14eEIbb2r6rRu6KMSOpkx6kqZKfBAsoHQC',NULL,'01000001111',NULL,NULL,'2024-10-10 21:15:47.445679',_binary 'a�ޝ�爵!�mv\�'),(6,'광주광역시 광산구 수완로 10길',NULL,'2001-04-11','2024-10-10 21:17:08.092627',NULL,'test02@moapay.com','F','김순옥','$2a$10$f9Z6G1GpxGfmQ7Q1w3mYeOM9TbdGLbOIalg23AU0UzyYqawnvKeli',NULL,'01000001112',NULL,NULL,'2024-10-10 21:17:08.092627',_binary '��·爵��C s'),(7,'광주광역시 광산구 수완로 10길',NULL,'2002-02-02','2024-10-10 21:18:21.887125',NULL,'test02@moapay.com','F','김혜자','$2a$10$7j6Z7ZLkMTBqTNzCgk6YQuZm4/GjI3naTosIFz0nCxfykHMVQeHGS',NULL,'01000001113',NULL,NULL,'2024-10-10 21:18:21.887125',_binary '��<��爵�TXP'),(8,'광주광역시 광산구 수완로 11길',NULL,'1999-09-18','2024-10-10 21:19:00.799128',NULL,'test03@moapay.com','F','김선미','$2a$10$OCZu9lWY1U8WnerdP2sAOehjif9SSfCWDH47viT8mN0hOdBrw8qCm',NULL,'01000001114',NULL,NULL,'2024-10-10 21:19:00.799128',_binary '\�\�\0�爵\��B�9'),(9,'광주광역시 광산구 수완로 12길',NULL,'1998-09-18','2024-10-10 21:20:05.378558',NULL,'test04@moapay.com','F','김희선','$2a$10$E17D.qCJhWzUdE7azb5sOOrEz5i0PvLpDhb7DZf9yTOnyxGKGSn3i',NULL,'01000001115',NULL,NULL,'2024-10-10 21:20:05.378558',_binary '�^�1�爵��l�\�'),(10,'광주광역시 광산구 수완로 13길',NULL,'1999-03-03','2024-10-10 21:21:04.343305',NULL,'test05@moapay.com','F','김아영','$2a$10$OASfOeha9NrmH2V/cFE4wOSrxB73HDH/CAt0iYFCUHRhNT.qMB6Gi',NULL,'01000001116',NULL,NULL,'2024-10-10 21:21:04.343305',_binary '���爵��\�E');
/*!40000 ALTER TABLE `member` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-10 14:22:57
