-- MySQL dump 10.13  Distrib 8.0.39, for Linux (x86_64)
--
-- Host: localhost    Database: store
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `item_info`
--

DROP TABLE IF EXISTS `item_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `item_info` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `item_name` varchar(100) DEFAULT NULL,
  `price` bigint NOT NULL,
  `quantity` bigint DEFAULT '1',
  `uuid` binary(16) NOT NULL,
  `item_id` bigint DEFAULT NULL,
  `order_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK7oxjwh1ovi3gnxnxekqe5udl6` (`uuid`),
  KEY `FK7rv96xx71j41audws5t7n2mxr` (`item_id`),
  KEY `FK5i5srebm5gjwy91isk75hf9su` (`order_id`),
  CONSTRAINT `FK5i5srebm5gjwy91isk75hf9su` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`),
  CONSTRAINT `FK7rv96xx71j41audws5t7n2mxr` FOREIGN KEY (`item_id`) REFERENCES `product` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=80 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_info`
--

LOCK TABLES `item_info` WRITE;
/*!40000 ALTER TABLE `item_info` DISABLE KEYS */;
INSERT INTO `item_info` VALUES (1,'BESPOKE 냉장고 4도어 키친핏 615L (UV탈취)',2260000,1,_binary '�r\�\0t�]\�t>h\'',1,1),(2,'BESPOKE 냉장고 4도어 키친핏 615L (UV탈취)',2260000,1,_binary '�r\n��s�\�\�԰�\�',1,2),(3,'BESPOKE 냉장고 4도어 키친핏 615L (UV탈취)',2260000,1,_binary '�rր\0��\03 \�',1,3),(4,'BESPOKE 냉장고 4도어 키친핏 615L (UV탈취)',2260000,1,_binary '�r׎wрd�\��B5�',1,4),(5,'BESPOKE 냉장고 4도어 키친핏 615L (UV탈취)',2260000,1,_binary '�r�%u/�)1x�\\�',1,5),(6,'BESPOKE 냉장고 4도어 키친핏 615L (UV탈취)',2260000,1,_binary '�r$r\�їUs�\�;',1,6),(7,'BESPOKE 냉장고 4도어 키친핏 615L (UV탈취)',2260000,1,_binary '�r��X\�d�\�',1,7),(8,'BESPOKE 냉장고 4도어 키친핏 615L (UV탈취)',2260000,1,_binary '�r�sw�c\r[\�D{',1,8),(9,'BESPOKE 냉장고 4도어 키친핏 615L (UV탈취)',2260000,1,_binary '�r��w��<~$|J�',1,9),(10,'BESPOKE 냉장고 4도어 키친핏 615L (UV탈취)',2260000,1,_binary '�r\"�\�s��2��\�\�',1,10),(11,'BESPOKE 냉장고 4도어 키친핏 615L (UV탈취)',2260000,1,_binary '�r\"ب{<�wF\�\n��',1,11),(12,'BESPOKE 냉장고 4도어 키친핏 615L (UV탈취)',2260000,1,_binary '�r$\�}~�u\�޻\�',1,12),(13,'BESPOKE 냉장고 4도어 키친핏 615L (UV탈취)',2260000,1,_binary '�r\'lSvՃ�b�*+\�',1,13),(14,'BESPOKE 냉장고 4도어 키친핏 615L (UV탈취)',2260000,1,_binary '�r)�Q����oc\�s\�',1,14),(16,'BESPOKE 냉장고 4도어 키친핏 615L (UV탈취)',2260000,1,_binary '�r2\�z��$=��u',1,16),(17,'BESPOKE 냉장고 4도어 키친핏 615L (UV탈취)',2260000,1,_binary '�r4O+B�\�\�g�ħV',1,17),(18,'BESPOKE 냉장고 4도어 키친핏 615L (UV탈취)',2260000,1,_binary '�r4�5~�ֲ�u��%',1,18),(19,'BESPOKE 냉장고 4도어 키친핏 615L (UV탈취)',2260000,1,_binary '�r:ЂsÏ\�z�\��}',1,19),(20,'BESPOKE 냉장고 4도어 키친핏 615L (UV탈취)',2260000,1,_binary '�rI\�p?�\�\�\Z»��',1,20),(21,'BESPOKE 냉장고 4도어 키친핏 615L (UV탈취)',2260000,1,_binary '�r^\�\�u��\�u�*\�',1,21),(22,'BESPOKE 냉장고 4도어 키친핏 615L (UV탈취)',2260000,1,_binary '�rh�\�v��C�\�MōS',1,22),(23,'BESPOKE 냉장고 4도어 키친핏 615L (UV탈취)',2260000,1,_binary '�rp\�a~͎\n\�\�F�\�',1,23),(24,'BESPOKE 냉장고 4도어 키친핏 615L (UV탈취)',2260000,1,_binary '�rp\�tl��uP���',1,24),(25,'BESPOKE 냉장고 4도어 키친핏 615L (UV탈취)',2260000,1,_binary '�r}��rĆ��\�\�2(�',1,25),(26,'BESPOKE 냉장고 4도어 키친핏 615L (UV탈취)',2260000,1,_binary '�r�z\r{��W�m�\��',1,26),(27,'BESPOKE 냉장고 4도어 키친핏 615L (UV탈취)',2260000,1,_binary '�r��EuϷO�ջ�\�',1,27),(28,'BESPOKE 냉장고 4도어 키친핏 615L (UV탈취)',2260000,1,_binary '�r���sP�d\'\�y�W/',1,28),(29,'BESPOKE 냉장고 4도어 키친핏 615L (UV탈취)',2260000,1,_binary '�r�\�{��9�qaK��',1,29),(30,'BESPOKE 냉장고 4도어 키친핏 615L (UV탈취)',2260000,1,_binary '�r���w��\��k�',1,30),(31,'BESPOKE 냉장고 4도어 키친핏 615L (UV탈취)',2260000,1,_binary '�r�\0�v}����+\�k\�',1,31),(32,'BESPOKE 냉장고 4도어 키친핏 615L (UV탈취)',2260000,1,_binary '�r�Mw�H)Eo&',1,32),(40,'BESPOKE 냉장고 4도어 키친핏 615L (UV탈취)',2260000,1,_binary '�r���q\���e6`q?r',1,40),(41,'BESPOKE 냉장고 4도어 키친핏 615L (UV탈취)',2260000,1,_binary '�r�\�Fu�G^���i�',1,41),(42,'BESPOKE 냉장고 4도어 키친핏 615L (UV탈취)',2260000,1,_binary '�r��O}F��\�c\�I��',1,42),(43,'BESPOKE 냉장고 4도어 키친핏 615L (UV탈취)',2260000,1,_binary '�r��kwԏ\�ȏ<��',1,43),(44,'BESPOKE 냉장고 4도어 키친핏 615L (UV탈취)',2260000,1,_binary '�r��u.�\���0�',1,44),(45,'BESPOKE 냉장고 4도어 키친핏 615L (UV탈취)',2260000,1,_binary '�r������\�\"*M\0',1,45),(46,'BESPOKE 냉장고 4도어 키친핏 615L (UV탈취)',2260000,1,_binary '�r�\0�q�������',1,46),(47,'BESPOKE 냉장고 4도어 키친핏 615L (UV탈취)',2260000,1,_binary '�r\�\�t��]\�\�%h�\�',1,47),(48,'BESPOKE 냉장고 4도어 키친핏 615L (UV탈취)',2260000,1,_binary '�r\�uAp4��k�\�6',1,48),(49,'BESPOKE 냉장고 4도어 키친핏 615L (UV탈취)',2260000,1,_binary '�r\�=r��TH�yb\�',1,49),(50,'BESPOKE 냉장고 4도어 키친핏 615L (UV탈취)',2260000,1,_binary '�r\�j3{ȶ5`�T{',1,50),(51,'BESPOKE 냉장고 4도어 키친핏 615L (UV탈취)',2260000,1,_binary '�r�e�uO�\�~��H�',1,51),(52,'BESPOKE 냉장고 4도어 키친핏 615L (UV탈취)',2260000,1,_binary '�s�\�5uԻz���o\�',1,52),(53,'BESPOKE 냉장고 4도어 키친핏 615L (UV탈취)',2260000,1,_binary '�tԋzB�8��0J�\�',1,53),(54,'BESPOKE 냉장고 4도어 키친핏 615L (UV탈취)',2260000,1,_binary '�tǐ\�s��\�\�!�1\�\�',1,54),(55,'BESPOKE 냉장고 4도어 키친핏 615L (UV탈취)',2260000,1,_binary '�t\�S\�}��䐗�x\�',1,55),(56,'BESPOKE 냉장고 4도어 키친핏 615L (UV탈취)',2260000,1,_binary '�t\�D�p9���)\�\\',1,56),(57,'BESPOKE 냉장고 4도어 키친핏 615L (UV탈취)',2260000,1,_binary '�uozw\�\�K\��b�\�',1,57),(58,'BESPOKE 냉장고 4도어 키친핏 615L (UV탈취)',2260000,1,_binary '�u\n��u����h+�\�',1,58),(59,'BESPOKE 냉장고 4도어 키친핏 615L (UV탈취)',2260000,1,_binary '�uf�{��3!�$�Gp',1,59),(60,'BESPOKE 냉장고 4도어 키친핏 615L (UV탈취)',2260000,1,_binary '�u\�z_�n\�w�\�;n',1,60),(61,'BESPOKE 냉장고 4도어 키친핏 615L (UV탈취)',2260000,1,_binary '�uЂuH�\��%dc�',1,61),(62,'BESPOKE 냉장고 4도어 키친핏 615L (UV탈취)',2260000,1,_binary '�u�\�ur���t �',1,62),(63,'BESPOKE 냉장고 4도어 키친핏 615L (UV탈취)',2260000,1,_binary '�uہs��S\�Qֱ�\�',1,63),(64,'BESPOKE 냉장고 4도어 키친핏 615L (UV탈취)',2260000,1,_binary '�uX�\rt�\�J6\r�H�',1,64),(65,'BESPOKE 냉장고 4도어 키친핏 615L (UV탈취)',2260000,1,_binary '�u�\�2{��\�\�\0N\�2',1,65),(66,'BESPOKE 냉장고 4도어 키친핏 615L (UV탈취)',2260000,1,_binary '�u�|\�{���\�m�|w',1,66),(67,'BESPOKE 냉장고 4도어 키친핏 615L (UV탈취)',2260000,1,_binary '�v\"q&��z�����',1,67),(68,'BESPOKE 냉장고 4도어 키친핏 615L (UV탈취)',2260000,1,_binary '�v ��{����\�R_\�g',1,68),(69,'BESPOKE 냉장고 4도어 키친핏 615L (UV탈취)',2260000,1,_binary '�v*pv���R�\�w�',1,69),(70,'BESPOKE 냉장고 4도어 키친핏 615L (UV탈취)',2260000,1,_binary '�vp\�Wt��*:\�J�',1,70),(71,'BESPOKE 냉장고 4도어 키친핏 615L (UV탈취)',2260000,1,_binary '�v�ƈw��\\�2E\r',1,71),(72,'BESPOKE 냉장고 4도어 키친핏 615L (UV탈취)',2260000,1,_binary '�v��\�y��\�\�>',1,72),(73,'BESPOKE 냉장고 4도어 키친핏 615L (UV탈취)',2260000,1,_binary '�v���xk�\�/W\�\�(',1,73),(74,'BESPOKE 냉장고 4도어 키친핏 615L (UV탈취)',2260000,1,_binary '�v�|�tf�\�h\�\�\�\�',1,74),(75,'BESPOKE 냉장고 4도어 키친핏 615L (UV탈취)',2260000,1,_binary '�v��\�~\�\Z��\�Rr',1,75),(76,'BESPOKE 냉장고 4도어 키친핏 615L (UV탈취)',2260000,1,_binary '�v��Hq\�#�Ȝ\�\�e',1,76),(77,'BESPOKE 냉장고 4도어 키친핏 615L (UV탈취)',2260000,1,_binary '�v�ɱw��?\�,����',1,77),(78,'BESPOKE 냉장고 4도어 키친핏 615L (UV탈취)',2260000,1,_binary '�v�(�yu�u\n��',1,78),(79,'BESPOKE 냉장고 4도어 키친핏 615L (UV탈취)',2260000,1,_binary '�v��\�qJ�L�-�xs',1,79);
/*!40000 ALTER TABLE `item_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item_info_seq`
--

DROP TABLE IF EXISTS `item_info_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `item_info_seq` (
  `next_val` bigint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_info_seq`
--

LOCK TABLES `item_info_seq` WRITE;
/*!40000 ALTER TABLE `item_info_seq` DISABLE KEYS */;
INSERT INTO `item_info_seq` VALUES (1);
/*!40000 ALTER TABLE `item_info_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `create_time` datetime(6) DEFAULT NULL,
  `customer_id` varchar(30) DEFAULT NULL,
  `state` enum('OrderCancel','OrderComplete','OrderCreated','PayComplete','PayWaiting') DEFAULT NULL,
  `total_price` bigint DEFAULT NULL,
  `update_time` datetime(6) DEFAULT NULL,
  `uuid` binary(16) NOT NULL,
  `merchant_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK8trmqe3eqy2ut1xr2i2atcaip` (`uuid`),
  KEY `FK8fvfob62jdf88auhfv4dj0w5m` (`merchant_id`),
  CONSTRAINT `FK8fvfob62jdf88auhfv4dj0w5m` FOREIGN KEY (`merchant_id`) REFERENCES `store` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=80 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES (1,'2024-10-10 01:02:53.762533','dpqls0356','OrderCreated',2260000,'2024-10-10 01:02:53.762533',_binary '�r\�\�|<�w�\�t�sE',1),(2,'2024-10-10 01:09:11.310107','dpqls0356','OrderCreated',2260000,'2024-10-10 01:09:11.310107',_binary '�r\n��{\�\�\�\�ŏ\�\�',1),(3,'2024-10-10 01:11:36.954700','dpqls0356','OrderCreated',2260000,'2024-10-10 01:11:36.954700',_binary '�r\�zt̴\Z\�t\'(�',1),(4,'2024-10-10 01:11:37.224848','dpqls0356','OrderCreated',2260000,'2024-10-10 01:11:37.224848',_binary '�r׈f��4�\�\�\�',1),(5,'2024-10-10 01:17:55.959535','dpqls0356','OrderCreated',2260000,'2024-10-10 01:17:55.959535',_binary '�r��p2�>�^ 6�\�',1),(6,'2024-10-10 01:18:24.414701','dpqls0356','OrderCreated',2260000,'2024-10-10 01:18:24.414701',_binary '�r~��R\�\�\��}B',1),(7,'2024-10-10 01:19:27.883168','dpqls0356','OrderCreated',2260000,'2024-10-10 01:19:27.883168',_binary '�r|z�E\�(\�ZBY',1),(8,'2024-10-10 01:22:18.631601','dpqls0356','OrderCreated',2260000,'2024-10-10 01:22:18.631601',_binary '�r�t2�\\\�\�}�',1),(9,'2024-10-10 01:23:17.935749','dpqls0356','OrderCreated',2260000,'2024-10-10 01:23:17.935749',_binary '�r��sߊڒ\�(q�',1),(10,'2024-10-10 01:35:32.395960','dpqls0356','OrderCreated',2260000,'2024-10-10 01:35:32.395960',_binary '�r\"��|ɇ\r\�\��',1),(11,'2024-10-10 01:35:39.299790','dpqls0356','OrderCreated',2260000,'2024-10-10 01:35:39.299790',_binary '�r\"أ|?�\�v\�\�\�\�',1),(12,'2024-10-10 01:37:49.816250','dpqls0356','OrderCreated',2260000,'2024-10-10 01:37:49.816250',_binary '�r$\�xy��컻ӶX\�',1),(13,'2024-10-10 01:40:39.245198','dpqls0356','OrderCreated',2260000,'2024-10-10 01:40:39.245198',_binary '�r\'lMy�\��.@G�',1),(14,'2024-10-10 01:43:04.139197','dpqls0356','OrderCreated',2260000,'2024-10-10 01:43:04.139197',_binary '�r)�Kq��Ş��I2',1),(16,'2024-10-10 01:53:05.149560','dpqls0356','OrderCreated',2260000,'2024-10-10 01:53:05.149560',_binary '�r2\��\���p;\�\�u',1),(17,'2024-10-10 01:54:43.749166','dpqls0356','OrderCreated',2260000,'2024-10-10 01:54:43.749166',_binary '�r4O%{؅��k;\n�',1),(18,'2024-10-10 01:55:28.048721','dpqls0356','OrderCreated',2260000,'2024-10-10 01:55:28.048721',_binary '�r4�0q��5�n\�H�',1),(19,'2024-10-10 02:01:50.077357','dpqls0356','OrderCreated',2260000,'2024-10-10 02:01:50.077357',_binary '�r:\�}ut�\��\�G`',1),(20,'2024-10-10 02:18:11.934071','dpqls0356','OrderCreated',2260000,'2024-10-10 02:18:11.934071',_binary '�rI\�\�q�����=$L3',1),(21,'2024-10-10 02:41:17.081852','dpqls0356','OrderCreated',2260000,'2024-10-10 02:41:17.081852',_binary '�r^\�y\��\�FUizC\Z',1),(22,'2024-10-10 02:51:55.815209','dpqls0356','OrderCreated',2260000,'2024-10-10 02:51:55.815209',_binary '�rh��r\�V&\�kyg�',1),(23,'2024-10-10 03:00:56.110242','dpqls0356','OrderCreated',2260000,'2024-10-10 03:00:56.110242',_binary '�rp\�0t���*\�,\�@;',1),(24,'2024-10-10 03:00:56.203073','dpqls0356','OrderCreated',2260000,'2024-10-10 03:00:56.203073',_binary '�rp\�{���\�\�G',1),(25,'2024-10-10 03:14:53.318623','dpqls0356','OrderCreated',2260000,'2024-10-10 03:14:53.318623',_binary '�r}��~����C\�\�\�',1),(26,'2024-10-10 03:34:18.465016','dpqls0356','OrderCreated',2260000,'2024-10-10 03:34:18.465016',_binary '�r�y\�}\�n#.�\�\�',1),(27,'2024-10-10 03:38:42.752889','dpqls0356','OrderCreated',2260000,'2024-10-10 03:38:42.752889',_binary '�r��@z���r�=av�',1),(28,'2024-10-10 03:39:54.256074','dpqls0356','OrderCreated',2260000,'2024-10-10 03:39:54.256074',_binary '�r���}�}`aqg\�',1),(29,'2024-10-10 03:44:36.116984','dpqls0356','OrderCreated',2260000,'2024-10-10 03:44:36.116984',_binary '�r�\�q�%˺�M\�',1),(30,'2024-10-10 03:45:48.049686','dpqls0356','OrderCreated',2260000,'2024-10-10 03:45:48.049686',_binary '�r���|`�\�\�Y·�\�',1),(31,'2024-10-10 03:45:48.315921','dpqls0356','OrderCreated',2260000,'2024-10-10 03:45:48.315921',_binary '�r�\0�v{���\�4\�2',1),(32,'2024-10-10 03:45:51.305094','dpqls0356','OrderCreated',2260000,'2024-10-10 03:45:51.305094',_binary '�r�Iw.�\�i\")�',1),(40,'2024-10-10 03:50:58.357469','dpqls0356','OrderCreated',2260000,'2024-10-10 03:50:58.357469',_binary '�r���v���a�d�y\�',1),(41,'2024-10-10 03:58:39.260630','dpqls0356','OrderCreated',2260000,'2024-10-10 03:58:39.260630',_binary '�r�\�~\Z�]�\�\�',1),(42,'2024-10-10 04:08:24.484775','dpqls0356','OrderCreated',2260000,'2024-10-10 04:08:24.484775',_binary '�r��%w����\�F\�',1),(43,'2024-10-10 04:16:06.584981','dpqls0356','OrderCreated',2260000,'2024-10-10 04:16:06.584981',_binary '�r��<x��4�E#�U',1),(44,'2024-10-10 04:16:29.227640','dpqls0356','OrderCreated',2260000,'2024-10-10 04:16:29.227640',_binary '�r��{��M(\�a�',1),(45,'2024-10-10 04:17:30.633170','dpqls0356','OrderCreated',2260000,'2024-10-10 04:17:30.633170',_binary '�r��zx�N��t�\�u',1),(46,'2024-10-10 04:26:13.096265','dpqls0356','PayComplete',2260000,'2024-10-10 04:26:33.691025',_binary '�r�\0iwI��ez�FԸ',1),(47,'2024-10-10 04:31:34.161205','dpqls0356','OrderCreated',2260000,'2024-10-10 04:31:34.161205',_binary '�r\�\�r��\�4>!�. ',1),(48,'2024-10-10 04:39:49.396214','dpqls0356','PayComplete',2260000,'2024-10-10 04:40:10.846190',_binary '�r\�u{%�IB/\�T',1),(49,'2024-10-10 05:03:36.791141','dpqls0356','PayComplete',2260000,'2024-10-10 05:03:56.338391',_binary '�r\�<\�u��x�\�\�W',1),(50,'2024-10-10 05:26:44.653565','dpqls0356','PayComplete',2260000,'2024-10-10 05:27:17.858760',_binary '�r\�j-q8�����N�',1),(51,'2024-10-10 05:30:00.119403','dpqls0356','PayComplete',2260000,'2024-10-10 05:30:27.504070',_binary '�r�e�z.�\�r�u\�\�',1),(52,'2024-10-10 10:10:03.524738','dpqls0356','PayComplete',2260000,'2024-10-10 10:10:58.518941',_binary '�s�\�wh�I\'M\�c�t',1),(53,'2024-10-10 10:18:49.990346','dpqls0356','OrderCreated',2260000,'2024-10-10 10:18:49.990346',_binary '�tԆ}��\�\0\�cl\�',1),(54,'2024-10-10 13:54:48.700301','dpqls0356','OrderCreated',2260000,'2024-10-10 13:54:48.700301',_binary '�tǐ}x��A��)\�',1),(55,'2024-10-10 14:04:23.018688','dpqls0356','OrderCreated',2260000,'2024-10-10 14:04:23.018688',_binary '�t\�S\�w�k\�\�E�',1),(56,'2024-10-10 14:19:36.564925','dpqls0356','OrderCreated',2260000,'2024-10-10 14:19:36.564925',_binary '�t\�Dv{���.v�\�܌',1),(57,'2024-10-10 15:02:23.420031','dpqls0356','OrderCreated',2260000,'2024-10-10 15:02:23.420031',_binary '�uo@sN��#\�\�#',1),(58,'2024-10-10 15:07:58.085291','dpqls0356','PayComplete',2260000,'2024-10-10 15:08:20.427318',_binary '�u\n��t\0���\�\�\Z&',1),(59,'2024-10-10 15:18:44.259671','dpqls0356','OrderCreated',2260000,'2024-10-10 15:18:44.259671',_binary '�uf�sȀ1���gȱ',1),(60,'2024-10-10 15:21:24.814676','dpqls0356','OrderCreated',2260000,'2024-10-10 15:21:24.814676',_binary '�u\�\�w7�\�{\�\�\�\n�',1),(61,'2024-10-10 15:22:27.963718','dpqls0356','OrderCreated',2260000,'2024-10-10 15:22:27.963718',_binary '�u\�{r+�.a���c',1),(62,'2024-10-10 15:24:35.268760','dpqls0356','PayComplete',2260000,'2024-10-10 15:25:38.531120',_binary '�u�\�r4�}\�eF\�k\�',1),(63,'2024-10-10 15:31:15.066981','dpqls0356','OrderCreated',2260000,'2024-10-10 15:31:15.066981',_binary '�u\�{u��B�eB�� ',1),(64,'2024-10-10 16:33:19.952013','dpqls0356','PayComplete',2260000,'2024-10-10 16:33:56.605552',_binary '�uX�\�p|�\�S3\�<Y',1),(65,'2024-10-10 17:49:55.707204','dpqls0356','OrderCreated',2260000,'2024-10-10 17:49:55.707204',_binary '�u�\��v\�z\�.	\�B',1),(66,'2024-10-10 17:50:39.453760','dpqls0356','OrderCreated',2260000,'2024-10-10 17:50:39.453760',_binary '�u�|\�{��\�.c��\Z\�',1),(67,'2024-10-10 20:03:31.549158','dpqls0356','OrderCreated',2260000,'2024-10-10 20:03:31.549158',_binary '�v!\�pQ��ɷC\"E+',1),(68,'2024-10-10 20:11:48.099336','dpqls0356','OrderCreated',2260000,'2024-10-10 20:11:48.099336',_binary '�v ��|âԏ�\�;�',1),(69,'2024-10-10 20:22:25.617804','dpqls0356','OrderCreated',2260000,'2024-10-10 20:22:25.617804',_binary '�v*o\�|��ɱ�r�',1),(70,'2024-10-10 21:39:20.146034','dpqls0356','PayComplete',2260000,'2024-10-10 21:40:00.143864',_binary '�vp\�Ry��\�?\�i�_!',1),(71,'2024-10-10 22:06:33.730228','dpqls0356','PayComplete',2260000,'2024-10-10 22:06:57.869974',_binary '�v�Ƃ}P�y�c��\�',1),(72,'2024-10-10 22:17:12.023015','dpqls0356','PayComplete',2260000,'2024-10-10 22:17:35.487790',_binary '�v��\�z��<�\��',1),(73,'2024-10-10 22:19:22.787235','dpqls0356','PayComplete',2260000,'2024-10-10 22:19:50.874016',_binary '�v���u���{?ZIZ:',1),(74,'2024-10-10 22:20:26.799323','dpqls0356','OrderCreated',2260000,'2024-10-10 22:20:26.799323',_binary '�v�|�se�\�\�����',1),(75,'2024-10-10 22:20:37.583219','dpqls0356','PayComplete',2260000,'2024-10-10 22:20:54.474222',_binary '�v��\�~J��:\�S^&',1),(76,'2024-10-10 22:22:03.971480','dpqls0356','OrderCreated',2260000,'2024-10-10 22:22:03.971480',_binary '�v��C{�	��\�)�',1),(77,'2024-10-10 22:29:30.797841','dpqls0356','OrderCreated',2260000,'2024-10-10 22:29:30.797841',_binary '�v�ɭy��\�x9`\�\�',1),(78,'2024-10-10 22:31:00.641142','dpqls0356','OrderCreated',2260000,'2024-10-10 22:31:00.641142',_binary '�v�(�u�\�@i���',1),(79,'2024-10-10 23:02:07.652870','dpqls0356','OrderCreated',2260000,'2024-10-10 23:02:07.652870',_binary '�v���v6�L=��\�\�',1);
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders_seq`
--

DROP TABLE IF EXISTS `orders_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders_seq` (
  `next_val` bigint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders_seq`
--

LOCK TABLES `orders_seq` WRITE;
/*!40000 ALTER TABLE `orders_seq` DISABLE KEYS */;
INSERT INTO `orders_seq` VALUES (1);
/*!40000 ALTER TABLE `orders_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_info`
--

DROP TABLE IF EXISTS `payment_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment_info` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `actual_amount` bigint DEFAULT NULL,
  `amount` bigint NOT NULL,
  `card_number` char(16) DEFAULT NULL,
  `payment_time` datetime(6) DEFAULT NULL,
  `status` enum('APPROVED','CANCELED','SETTLED') DEFAULT NULL,
  `uuid` binary(16) NOT NULL,
  `order_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK6s4aqlbi3rljewbw08e8r1ui` (`uuid`),
  KEY `FKlvi5j82l41gxfinwo8npi37qc` (`order_id`),
  CONSTRAINT `FKlvi5j82l41gxfinwo8npi37qc` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_info`
--

LOCK TABLES `payment_info` WRITE;
/*!40000 ALTER TABLE `payment_info` DISABLE KEYS */;
INSERT INTO `payment_info` VALUES (1,1582000,2260000,'3998541707334420','2024-10-10 04:26:33.684316','APPROVED',_binary '�r�P\�w��s\�e\�	i\�',46),(2,1582000,2260000,'3998541707334420','2024-10-10 04:40:10.830489','APPROVED',_binary '�r\�\�\�u0�M�`��?E',48),(3,1582000,2260000,'3998541707334420','2024-10-10 05:03:56.309440','APPROVED',_binary '�r\�x��\��\�\�H��',49),(4,1582000,2260000,'3998541707334420','2024-10-10 05:27:17.848185','APPROVED',_binary '�r\�\�\�s&�\\w\�l.U',50),(5,1582000,2260000,'3998541707334420','2024-10-10 05:30:27.498873','APPROVED',_binary '�r�Ъv)�61Ƴa��',51),(6,1640000,1660000,'3998541707334420','2024-10-10 10:10:58.435561','APPROVED',_binary '�s���~Ò`\"Ї�2y',52),(7,300000,300000,'9278568627446081','2024-10-10 10:10:58.452052','APPROVED',_binary '�s������7\�\�6��',52),(8,300000,300000,'6509702494417705','2024-10-10 10:10:58.465411','APPROVED',_binary '�s���w�\�`z�YC)',52),(9,1640000,1640000,'6135890187515481','2024-10-10 15:08:20.407461','APPROVED',_binary '�u\n\�w▟9�\�',58),(10,300000,320000,'1440817966546838','2024-10-10 15:08:20.412218','APPROVED',_binary '�u\n\�y1�~n\"\n;\0C',58),(11,300000,300000,'1303554057674288','2024-10-10 15:08:20.415700','APPROVED',_binary '�u\n\�~��\�\�b\�',58),(12,2260000,2260000,'7997093824822165','2024-10-10 15:25:38.489851','APPROVED',_binary '�u\Z��{=�VQ��|�',62),(13,2260000,2260000,'7997093824822165','2024-10-10 16:33:56.587379','APPROVED',_binary '�uY@\�[��\�\0 |\�',64),(14,1760000,1760000,'2114120546082246','2024-10-10 21:40:00.130777','APPROVED',_binary '�vqu�s|���\\AjY',70),(15,500000,500000,'1796090396860082','2024-10-10 21:40:00.134988','APPROVED',_binary '�vqu�|̆\�\��\�	\�',70),(16,2260000,2260000,'7997093824822165','2024-10-10 22:06:57.867718','APPROVED',_binary '�v�$\�|>�H��\��j',71),(17,2260000,2260000,'3998541707334420','2024-10-10 22:17:35.485465','APPROVED',_binary '�v�\�}u������B',72),(18,2260000,2260000,'3998541707334420','2024-10-10 22:19:50.870391','APPROVED',_binary '�v�\�VyG�.u�\�\\+',73),(19,2260000,2260000,'3998541707334420','2024-10-10 22:20:54.470725','APPROVED',_binary '�v�\�\�r^��j\��A',75);
/*!40000 ALTER TABLE `payment_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_info_seq`
--

DROP TABLE IF EXISTS `payment_info_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment_info_seq` (
  `next_val` bigint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_info_seq`
--

LOCK TABLES `payment_info_seq` WRITE;
/*!40000 ALTER TABLE `payment_info_seq` DISABLE KEYS */;
INSERT INTO `payment_info_seq` VALUES (1);
/*!40000 ALTER TABLE `payment_info_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `create_time` datetime(6) DEFAULT NULL,
  `image_url` varchar(200) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `price` bigint NOT NULL,
  `update_time` datetime(6) DEFAULT NULL,
  `uuid` binary(16) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK24bc4yyyk3fj3h7ku64i3yuog` (`uuid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES (1,NULL,'/assets/image/ref1.png','BESPOKE 냉장고 4도어 키친핏 615L (UV탈취)',2260000,'2024-10-09 14:09:46.000000',_binary '�P\�\rw엢n*�d�');
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_seq`
--

DROP TABLE IF EXISTS `product_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_seq` (
  `next_val` bigint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_seq`
--

LOCK TABLES `product_seq` WRITE;
/*!40000 ALTER TABLE `product_seq` DISABLE KEYS */;
INSERT INTO `product_seq` VALUES (1);
/*!40000 ALTER TABLE `product_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `store`
--

DROP TABLE IF EXISTS `store`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `store` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `admin_id` varchar(20) DEFAULT NULL,
  `admin_password` varchar(50) DEFAULT NULL,
  `category_id` char(5) DEFAULT NULL,
  `category_name` varchar(20) DEFAULT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `merchant_url` varchar(255) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `update_time` datetime(6) DEFAULT NULL,
  `uuid` binary(16) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK65bg7us6cywtttej1rukmr9uo` (`uuid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `store`
--

LOCK TABLES `store` WRITE;
/*!40000 ALTER TABLE `store` DISABLE KEYS */;
INSERT INTO `store` VALUES (1,'dpqls0356','dpqls0356','C0008','쇼핑',NULL,'https://moapay-samsungmall-clone.web.app/','삼성전자온라인쇼핑몰',NULL,_binary '�P\�\r{\�En�\�\�\'');
/*!40000 ALTER TABLE `store` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `store_seq`
--

DROP TABLE IF EXISTS `store_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `store_seq` (
  `next_val` bigint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `store_seq`
--

LOCK TABLES `store_seq` WRITE;
/*!40000 ALTER TABLE `store_seq` DISABLE KEYS */;
INSERT INTO `store_seq` VALUES (1);
/*!40000 ALTER TABLE `store_seq` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-10 14:27:30
